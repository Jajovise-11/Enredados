import { Component } from '@angular/core';

@Component({
  selector: 'app-novias',
  standalone: true,
  imports: [],
  templateUrl: './novias.component.html',
  styleUrl: './novias.component.css'
})
export class NoviasComponent {

}
