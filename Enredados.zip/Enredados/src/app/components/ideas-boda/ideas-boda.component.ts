import { Component } from '@angular/core';

@Component({
  selector: 'app-ideas-boda',
  standalone: true,
  imports: [],
  templateUrl: './ideas-boda.component.html',
  styleUrl: './ideas-boda.component.css'
})
export class IdeasBodaComponent {

}
