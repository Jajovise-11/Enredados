import { Component } from '@angular/core';

@Component({
  selector: 'app-comunidad',
  standalone: true,
  imports: [],
  templateUrl: './comunidad.component.html',
  styleUrl: './comunidad.component.css'
})
export class ComunidadComponent {

}
