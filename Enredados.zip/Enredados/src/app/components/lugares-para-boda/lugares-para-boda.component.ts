import { Component } from '@angular/core';

@Component({
  selector: 'app-lugares-para-boda',
  standalone: true,
  imports: [],
  templateUrl: './lugares-para-boda.component.html',
  styleUrl: './lugares-para-boda.component.css'
})
export class LugaresParaBodaComponent {

}
