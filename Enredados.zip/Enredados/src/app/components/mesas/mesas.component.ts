import { Component } from '@angular/core';

@Component({
  selector: 'app-mesas',
  standalone: true,
  imports: [],
  templateUrl: './mesas.component.html',
  styleUrl: './mesas.component.css'
})
export class MesasComponent {

}
