import { Component } from '@angular/core';

@Component({
  selector: 'app-presupuestador',
  standalone: true,
  imports: [],
  templateUrl: './presupuestador.component.html',
  styleUrl: './presupuestador.component.css'
})
export class PresupuestadorComponent {

}
