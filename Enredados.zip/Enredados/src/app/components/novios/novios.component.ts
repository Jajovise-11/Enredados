import { Component } from '@angular/core';

@Component({
  selector: 'app-novios',
  standalone: true,
  imports: [],
  templateUrl: './novios.component.html',
  styleUrl: './novios.component.css'
})
export class NoviosComponent {

}
