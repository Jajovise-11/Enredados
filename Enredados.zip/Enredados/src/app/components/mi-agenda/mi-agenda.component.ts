import { Component } from '@angular/core';

@Component({
  selector: 'app-mi-agenda',
  standalone: true,
  imports: [],
  templateUrl: './mi-agenda.component.html',
  styleUrl: './mi-agenda.component.css'
})
export class MiAgendaComponent {

}
