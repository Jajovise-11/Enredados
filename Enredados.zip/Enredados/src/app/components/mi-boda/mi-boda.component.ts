import { Component } from '@angular/core';

@Component({
  selector: 'app-mi-boda',
  standalone: true,
  imports: [],
  templateUrl: './mi-boda.component.html',
  styleUrl: './mi-boda.component.css'
})
export class MiBodaComponent {

}
