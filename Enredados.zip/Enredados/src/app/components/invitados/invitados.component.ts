import { Component } from '@angular/core';

@Component({
  selector: 'app-invitados',
  standalone: true,
  imports: [],
  templateUrl: './invitados.component.html',
  styleUrl: './invitados.component.css'
})
export class InvitadosComponent {

}
