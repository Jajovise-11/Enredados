import { Component } from '@angular/core';

@Component({
  selector: 'app-vestidos',
  standalone: true,
  imports: [],
  templateUrl: './vestidos.component.html',
  styleUrl: './vestidos.component.css'
})
export class VestidosComponent {

}
