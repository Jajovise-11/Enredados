import pymysql

# Configuración para que PyMySQL funcione correctamente
pymysql.version_info = (1, 4, 6, 'final', 0)
pymysql.install_as_MySQLdb()